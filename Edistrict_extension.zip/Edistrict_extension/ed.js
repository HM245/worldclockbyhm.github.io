var url = document.querySelector("a");
url.href = "javascript:window.open('edMarkflowContainer.aspx');";